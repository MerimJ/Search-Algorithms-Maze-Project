# SolAStarMaze (ProjAI Maze)

Interactive desktop application for **visualizing and comparing path-finding algorithms** in a grid-based maze:
- **Breadth‑First Search (BFS)**
- **Dijkstra’s algorithm**
- **A\*** (A-star)

The app lets you change maze size, obstacle density, diagonal movement, and animation speed, then observe how each algorithm explores the state-space and constructs the final path.

## Demo materials
- Project report: `docs/Maze_Report_MJ.pdf`
- Slides: `docs/Maze.pptx`

## Features
- Real-time visualization (visited/frontier/path coloring)
- Configurable maze generation (rows/cols, wall density, guaranteed solvable option)
- Algorithm switch: BFS / Dijkstra / A*
- Optional diagonal movement
- Animation speed control

## Project structure
```
.
├─ CMakeLists.txt
├─ astarmaze.cmake
├─ res/                 # UI resources, translations, app icons
├─ src/                 # C++ source code (GUI + algorithms)
└─ docs/                # report + slides
```

## Build prerequisites (important)
This project is built on the **natGUI / DevEnv** toolchain used in the course environment.

`CMakeLists.txt` expects these files to exist on your machine:
- `${HOME}/Work/DevEnv/Common.cmake`
- `${HOME}/Work/DevEnv/natGUI.cmake`

If you are building on a new computer, first set up the same DevEnv/natGUI folder (or update the paths inside `CMakeLists.txt` accordingly).

## Build (CMake)

### macOS (Xcode)
```bash
cmake -S . -B build -G "Xcode"
cmake --build build --config Release
```

### macOS / Linux (Makefiles or Ninja)
```bash
cmake -S . -B build
cmake --build build -j
```

### Windows (Visual Studio)
```bat
cmake -S . -B build -G "Visual Studio 17 2022"
cmake --build build --config Release
```

## Run
After building, start the produced executable (location depends on generator and OS).  
On macOS/Xcode it will be inside `build/Release/`.

## Author
**Merim Jusufbegović**  
Faculty of Electrical Engineering (ETF), University of Sarajevo

## Notes
- This repository contains only the project source + resources. The course GUI framework/toolchain is external (natGUI/DevEnv).
